
import { GoogleGenAI, Type } from "@google/genai";
import { ChecklistResponse, ChecklistItem, User } from "../types";

export const analyzeChecklistData = async (
  responses: ChecklistResponse[],
  items: ChecklistItem[],
  users: User[]
) => {
  try {
    // Initialize Gemini client right before making an API call to ensure it uses the most up-to-date environment/key
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

    const dataContext = JSON.stringify({
      totalResponses: responses.length,
      recentResponses: responses.slice(-10),
      checklistItems: items,
      userCount: users.length
    });

    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Analise estes dados de checklist corporativo e forneça 3 sugestões curtas de melhoria e uma conclusão de status geral de conformidade (Normal, Atenção ou Crítico). Retorne em formato JSON. Dados: ${dataContext}`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            status: { type: Type.STRING },
            suggestions: {
              type: Type.ARRAY,
              items: { type: Type.STRING }
            },
            summary: { type: Type.STRING }
          },
          required: ["status", "suggestions", "summary"]
        }
      }
    });

    // Access .text as a property, not a method, as per SDK guidelines
    const text = response.text;
    if (!text) {
      console.warn("Gemini returned empty text.");
      return null;
    }
    
    return JSON.parse(text);
  } catch (error) {
    console.error("Gemini Error:", error);
    return null;
  }
};
