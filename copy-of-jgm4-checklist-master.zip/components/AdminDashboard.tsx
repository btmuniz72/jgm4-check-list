
import React, { useState, useEffect, useMemo } from 'react';
import { User, ChecklistItem, ChecklistResponse } from '../types';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, BarChart, Bar, Legend } from 'recharts';
import { analyzeChecklistData } from '../services/geminiService';

interface AdminDashboardProps {
  users: User[];
  setUsers: React.Dispatch<React.SetStateAction<User[]>>;
  items: ChecklistItem[];
  setItems: React.Dispatch<React.SetStateAction<ChecklistItem[]>>;
  responses: ChecklistResponse[];
}

const APP_VERSION: string = "1.0.0";
const MOCK_REMOTE_VERSION: string = "1.1.0";

const AdminDashboard: React.FC<AdminDashboardProps> = ({ users, setUsers, items, setItems, responses }) => {
  const [tab, setTab] = useState<'stats' | 'users' | 'checklist'>('stats');
  const [aiInsight, setAiInsight] = useState<{status: string, suggestions: string[], summary: string} | null>(null);
  const [loadingAi, setLoadingAi] = useState(false);
  const [showVersionAlert, setShowVersionAlert] = useState(false);

  // Modal States
  const [showUserModal, setShowUserModal] = useState(false);
  const [showItemModal, setShowItemModal] = useState(false);
  const [editingItemId, setEditingItemId] = useState<string | null>(null);

  // Form States
  const [newUser, setNewUser] = useState({ name: '', role: '', phone: '', email: '' });
  const [newItem, setNewItem] = useState<{ question: string; category: string; assignedUserIds: string[] }>({ 
    question: '', 
    category: '', 
    assignedUserIds: [] 
  });

  useEffect(() => {
    const checkVersion = setTimeout(() => {
      if (MOCK_REMOTE_VERSION !== APP_VERSION) {
        setShowVersionAlert(true);
      }
    }, 3000);
    return () => clearTimeout(checkVersion);
  }, []);

  const stats = useMemo(() => {
    const total = responses.length;
    const conforms = responses.reduce((acc, r) => acc + Object.values(r.answers).filter(v => v).length, 0);
    const nonConforms = responses.reduce((acc, r) => acc + Object.values(r.answers).filter(v => !v).length, 0);
    
    // Calculate total possible checks based on historical responses and item counts
    let totalPossibleChecks = 0;
    responses.forEach(r => {
      // Find items that were active/assigned at the time (simplified: use current items length or answer count)
      totalPossibleChecks += Object.keys(r.answers).length;
    });

    const complianceRate = totalPossibleChecks > 0 ? (conforms / totalPossibleChecks) * 100 : 0;

    // Time Series Data (Checklists per day)
    const days: Record<string, number> = {};
    responses.forEach(r => {
      const day = new Date(r.timestamp).toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' });
      days[day] = (days[day] || 0) + 1;
    });
    const timeData = Object.keys(days).map(d => ({ name: d, count: days[d] })).sort().slice(-7);

    // Compliance by Category
    const categoryStats: Record<string, { ok: number, total: number }> = {};
    responses.forEach(r => {
      Object.entries(r.answers).forEach(([itemId, isOk]) => {
        const item = items.find(i => i.id === itemId);
        const category = item?.category || 'Outros';
        if (!categoryStats[category]) categoryStats[category] = { ok: 0, total: 0 };
        categoryStats[category].total++;
        if (isOk) categoryStats[category].ok++;
      });
    });
    const categoryData = Object.keys(categoryStats).map(cat => ({
      name: cat,
      conformidade: Math.round((categoryStats[cat].ok / categoryStats[cat].total) * 100),
      total: categoryStats[cat].total
    }));

    // Compliance by User
    const userStats: Record<string, { ok: number, total: number }> = {};
    responses.forEach(r => {
      const user = users.find(u => u.id === r.userId);
      const userName = user?.name || 'Desconhecido';
      if (!userStats[userName]) userStats[userName] = { ok: 0, total: 0 };
      Object.values(r.answers).forEach(v => {
        userStats[userName].total++;
        if (v) userStats[userName].ok++;
      });
    });
    const userData = Object.keys(userStats).map(uname => ({
      name: uname.split(' ')[0], // First name for chart
      conformidade: Math.round((userStats[uname].ok / userStats[uname].total) * 100)
    }));

    const pieData = [
      { name: 'Conformes', value: conforms, color: '#10b981' },
      { name: 'Não Conformes', value: nonConforms, color: '#ef4444' }
    ];

    // Today's participation
    const today = new Date().toLocaleDateString();
    const todayResponses = responses.filter(r => new Date(r.timestamp).toLocaleDateString() === today);
    const uniqueUsersToday = new Set(todayResponses.map(r => r.userId)).size;
    const participationRate = users.length > 0 ? (uniqueUsersToday / users.length) * 100 : 0;

    return { total, complianceRate, timeData, pieData, categoryData, userData, participationRate, uniqueUsersToday };
  }, [responses, items, users]);

  const fetchAiInsights = async () => {
    setLoadingAi(true);
    const insight = await analyzeChecklistData(responses, items, users);
    setAiInsight(insight);
    setLoadingAi(false);
  };

  useEffect(() => {
    if (responses.length > 0 && !aiInsight) {
      fetchAiInsights();
    }
  }, [responses]);

  const handleAddUser = (e: React.FormEvent) => {
    e.preventDefault();
    if (newUser.name && newUser.role && newUser.phone && newUser.email) {
      setUsers([...users, { id: crypto.randomUUID(), ...newUser }]);
      setNewUser({ name: '', role: '', phone: '', email: '' });
      setShowUserModal(false);
    }
  };

  const handleSaveItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (newItem.question && newItem.category) {
      if (editingItemId) {
        setItems(items.map(item => item.id === editingItemId ? { ...item, ...newItem } : item));
      } else {
        if (newItem.assignedUserIds.length === 0) {
          alert("Selecione pelo menos um colaborador para este item.");
          return;
        }
        setItems([...items, { id: crypto.randomUUID(), ...newItem }]);
      }
      closeItemModal();
    }
  };

  const openEditModal = (item: ChecklistItem) => {
    setEditingItemId(item.id);
    setNewItem({
      question: item.question,
      category: item.category,
      assignedUserIds: [...item.assignedUserIds]
    });
    setShowItemModal(true);
  };

  const closeItemModal = () => {
    setEditingItemId(null);
    setNewItem({ question: '', category: '', assignedUserIds: [] });
    setShowItemModal(false);
  };

  const toggleUserAssignment = (userId: string) => {
    setNewItem(prev => {
      const isAssigned = prev.assignedUserIds.includes(userId);
      return {
        ...prev,
        assignedUserIds: isAssigned 
          ? prev.assignedUserIds.filter(id => id !== userId)
          : [...prev.assignedUserIds, userId]
      };
    });
  };

  const removeUser = (id: string) => {
    if (confirm('Tem certeza que deseja remover este colaborador?')) {
      setUsers(users.filter(u => u.id !== id));
      setItems(items.map(item => ({
        ...item,
        assignedUserIds: item.assignedUserIds.filter(uid => uid !== id)
      })));
    }
  };

  const removeItem = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    if (confirm('Tem certeza que deseja remover este item?')) {
      setItems(items.filter(i => i.id !== id));
    }
  };

  return (
    <div className="flex-1 flex flex-col md:flex-row h-full overflow-hidden">
      {/* Sidebar Nav */}
      <nav className="w-full md:w-64 bg-white border-b md:border-b-0 md:border-r border-slate-200 p-4 space-y-1">
        <button 
          onClick={() => setTab('stats')}
          className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl transition-all ${tab === 'stats' ? 'bg-indigo-50 text-indigo-700 font-bold' : 'text-slate-500 hover:bg-slate-50'}`}
        >
          <i className="fas fa-chart-line w-5"></i> <span>Dashboard</span>
        </button>
        <button 
          onClick={() => setTab('users')}
          className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl transition-all ${tab === 'users' ? 'bg-indigo-50 text-indigo-700 font-bold' : 'text-slate-500 hover:bg-slate-50'}`}
        >
          <i className="fas fa-users w-5"></i> <span>Colaboradores</span>
        </button>
        <button 
          onClick={() => setTab('checklist')}
          className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl transition-all ${tab === 'checklist' ? 'bg-indigo-50 text-indigo-700 font-bold' : 'text-slate-500 hover:bg-slate-50'}`}
        >
          <i className="fas fa-list-check w-5"></i> <span>Itens Checklist</span>
        </button>
      </nav>

      {/* Content Area */}
      <div className="flex-1 overflow-y-auto p-4 md:p-8 bg-slate-50 relative">
        {showVersionAlert && (
          <div className="mb-6 animate-slideDown">
            <div className="bg-indigo-600 text-white px-4 py-3 rounded-2xl flex items-center justify-between shadow-lg shadow-indigo-100 border border-indigo-400">
              <div className="flex items-center space-x-3">
                <div className="bg-white/20 p-2 rounded-lg">
                  <i className="fas fa-rocket animate-pulse"></i>
                </div>
                <div className="text-sm">
                  <p className="font-bold">Nova versão disponível (v{MOCK_REMOTE_VERSION})</p>
                  <p className="text-xs text-indigo-100 opacity-80">Desenvolvido pela JGM4 Consultoria.</p>
                </div>
              </div>
              <button onClick={() => setShowVersionAlert(false)} className="text-white/60 hover:text-white transition-colors">
                <i className="fas fa-times"></i>
              </button>
            </div>
          </div>
        )}

        {tab === 'stats' && (
          <div className="space-y-8 animate-fadeIn">
            {/* Header */}
            <div className="flex justify-between items-center">
              <div>
                <h2 className="text-2xl font-bold text-slate-800">Métricas JGM4</h2>
                <p className="text-sm text-slate-500">Gestão Eficiente de Checklist</p>
              </div>
              <button 
                onClick={fetchAiInsights} 
                disabled={loadingAi}
                className="bg-indigo-600 text-white px-5 py-2.5 rounded-xl text-sm font-bold hover:bg-indigo-700 transition-all flex items-center shadow-lg shadow-indigo-100"
              >
                <i className={`fas fa-magic mr-2 ${loadingAi ? 'animate-spin' : ''}`}></i>
                {loadingAi ? 'Analisando dados...' : 'Gerar Insights IA'}
              </button>
            </div>

            {/* KPI Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm transition-transform hover:scale-[1.02]">
                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">Checklists Hoje</p>
                <h3 className="text-3xl font-black text-slate-800">{stats.uniqueUsersToday}</h3>
                <p className="text-[10px] text-slate-500 mt-2">de {users.length} colaboradores ativos</p>
              </div>
              <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm transition-transform hover:scale-[1.02]">
                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">Conformidade Geral</p>
                <h3 className={`text-3xl font-black ${stats.complianceRate >= 90 ? 'text-green-500' : 'text-indigo-600'}`}>
                  {stats.complianceRate.toFixed(1)}%
                </h3>
                <div className="w-full bg-slate-100 h-1.5 rounded-full mt-3 overflow-hidden">
                  <div className="bg-indigo-500 h-full" style={{ width: `${stats.complianceRate}%` }}></div>
                </div>
              </div>
              <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm transition-transform hover:scale-[1.02]">
                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">Participação Diária</p>
                <h3 className="text-3xl font-black text-slate-800">{stats.participationRate.toFixed(0)}%</h3>
                <p className="text-[10px] text-slate-500 mt-2">Atividade na plataforma hoje</p>
              </div>
              <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm transition-transform hover:scale-[1.02]">
                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">Alertas Ativos</p>
                <h3 className="text-3xl font-black text-red-500">
                  {responses.reduce((acc, r) => acc + Object.values(r.answers).filter(v => !v).length, 0)}
                </h3>
                <p className="text-[10px] text-slate-500 mt-2">Não conformidades detectadas</p>
              </div>
            </div>

            {/* Gemini Insights Section (Managerial View) */}
            {aiInsight && (
              <div className="bg-white border-2 border-indigo-100 p-8 rounded-[2.5rem] shadow-xl relative overflow-hidden">
                <div className="absolute top-[-20%] right-[-10%] opacity-[0.03] pointer-events-none">
                  <i className="fas fa-microchip text-[15rem] text-indigo-900"></i>
                </div>
                <div className="relative z-10">
                  <div className="flex items-center space-x-3 mb-6">
                    <div className="bg-indigo-600 p-3 rounded-2xl shadow-lg shadow-indigo-100">
                      <i className="fas fa-brain text-white text-xl"></i>
                    </div>
                    <div>
                      <h4 className="font-black text-indigo-900 uppercase tracking-tighter text-lg">Análise Consultiva JGM4 + AI</h4>
                      <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Processamento em Tempo Real</p>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
                    <div className="lg:col-span-4">
                      <div className={`p-6 rounded-3xl border-2 mb-4 flex flex-col items-center text-center ${aiInsight.status === 'Crítico' ? 'bg-red-50 border-red-200 text-red-700' : 'bg-green-50 border-green-200 text-green-700'}`}>
                        <span className="text-[10px] font-black uppercase mb-1">Status Operacional</span>
                        <span className="text-4xl font-black">{aiInsight.status}</span>
                      </div>
                      <p className="text-slate-600 text-sm italic font-medium">"{aiInsight.summary}"</p>
                    </div>
                    <div className="lg:col-span-8 flex flex-col justify-center space-y-3">
                      <p className="text-xs font-black text-slate-400 uppercase tracking-widest mb-2">Recomendações Estratégicas</p>
                      {aiInsight.suggestions.map((s, i) => (
                        <div key={i} className="flex items-center space-x-4 bg-slate-50 p-4 rounded-2xl border border-slate-100 hover:border-indigo-200 transition-all">
                          <div className="bg-white w-8 h-8 rounded-full flex items-center justify-center shadow-sm border border-slate-100 text-indigo-600 font-bold">
                            {i+1}
                          </div>
                          <p className="text-sm font-semibold text-slate-700">{s}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Charts Section */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {/* Compliance by Category */}
              <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm flex flex-col">
                <div className="flex justify-between items-center mb-6">
                  <h4 className="font-black text-slate-800 uppercase tracking-widest text-xs">Conformidade por Categoria</h4>
                  <span className="text-[10px] font-bold text-slate-400 bg-slate-50 px-2 py-1 rounded-full">% Sucesso</span>
                </div>
                <div className="flex-1 min-h-[250px]">
                   <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={stats.categoryData} layout="vertical">
                        <XAxis type="number" domain={[0, 100]} hide />
                        <YAxis dataKey="name" type="category" axisLine={false} tickLine={false} tick={{fontSize: 10, fontWeight: 700, fill: '#64748b'}} width={100} />
                        <Tooltip 
                          cursor={{fill: '#f8fafc'}}
                          contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                        />
                        <Bar dataKey="conformidade" fill="#6366f1" radius={[0, 10, 10, 0]} barSize={20} />
                      </BarChart>
                   </ResponsiveContainer>
                </div>
              </div>

              {/* Performance by User */}
              <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm flex flex-col">
                <div className="flex justify-between items-center mb-6">
                  <h4 className="font-black text-slate-800 uppercase tracking-widest text-xs">Performance do Time</h4>
                  <span className="text-[10px] font-bold text-slate-400 bg-slate-50 px-2 py-1 rounded-full">Score Individual</span>
                </div>
                <div className="flex-1 min-h-[250px]">
                   <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={stats.userData}>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                        <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fontSize: 10, fontWeight: 700, fill: '#94a3b8'}} />
                        <YAxis axisLine={false} tickLine={false} tick={{fontSize: 10, fontWeight: 700, fill: '#94a3b8'}} unit="%" />
                        <Tooltip />
                        <Line type="step" dataKey="conformidade" stroke="#10b981" strokeWidth={4} dot={{ r: 6, fill: '#10b981', strokeWidth: 2, stroke: '#fff' }} />
                      </LineChart>
                   </ResponsiveContainer>
                </div>
              </div>
            </div>

            {/* Recent Submissions List */}
            <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm">
              <h4 className="font-black text-slate-800 uppercase tracking-widest text-xs mb-6">Logs Recentes</h4>
              <div className="space-y-4">
                {responses.slice(-5).reverse().map(resp => {
                  const user = users.find(u => u.id === resp.userId);
                  const fails = Object.values(resp.answers).filter(v => !v).length;
                  return (
                    <div key={resp.id} className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl border border-slate-100">
                      <div className="flex items-center space-x-4">
                        <div className="bg-white w-10 h-10 rounded-full flex items-center justify-center shadow-sm font-bold text-indigo-600 border border-slate-100">
                          {user?.name.charAt(0)}
                        </div>
                        <div>
                          <p className="text-sm font-bold text-slate-800">{user?.name}</p>
                          <p className="text-[10px] text-slate-400 font-medium">{new Date(resp.timestamp).toLocaleString()}</p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-3">
                        <span className={`px-3 py-1 rounded-full text-[10px] font-black uppercase ${fails > 0 ? 'bg-red-100 text-red-600' : 'bg-green-100 text-green-600'}`}>
                          {fails > 0 ? `${fails} Falhas` : '100% OK'}
                        </span>
                        <i className="fas fa-chevron-right text-slate-300 text-xs"></i>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {tab === 'users' && (
          <div className="space-y-6 animate-fadeIn">
            <div className="flex justify-between items-center">
               <h2 className="text-2xl font-bold text-slate-800">Colaboradores JGM4</h2>
               <button onClick={() => setShowUserModal(true)} className="bg-indigo-600 text-white px-4 py-2 rounded-xl text-sm font-bold hover:bg-indigo-700 transition-all shadow-md">
                 <i className="fas fa-user-plus mr-2"></i> Novo Cadastro
               </button>
            </div>
            <div className="bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-sm">
              <table className="w-full text-left">
                <thead className="bg-slate-50 border-b border-slate-200">
                  <tr>
                    <th className="px-6 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">Colaborador</th>
                    <th className="px-6 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">Cargo</th>
                    <th className="px-6 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">Contato</th>
                    <th className="px-6 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest text-right">Gerenciar</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {users.map(user => (
                    <tr key={user.id} className="hover:bg-slate-50/50 transition-colors">
                      <td className="px-6 py-4">
                        <div className="flex items-center space-x-3">
                          <div className="w-8 h-8 rounded-full bg-indigo-50 flex items-center justify-center text-indigo-600 font-bold text-xs border border-indigo-100">
                            {user.name.charAt(0)}
                          </div>
                          <span className="font-bold text-slate-700">{user.name}</span>
                        </div>
                      </td>
                      <td className="px-6 py-4 text-sm text-slate-500 font-medium">{user.role}</td>
                      <td className="px-6 py-4">
                        <div className="text-xs font-bold text-slate-600">{user.phone}</div>
                        <div className="text-[10px] text-slate-400">{user.email}</div>
                      </td>
                      <td className="px-6 py-4 text-right">
                        <button onClick={() => removeUser(user.id)} className="text-slate-300 hover:text-red-500 transition-colors p-2">
                          <i className="fas fa-trash-alt"></i>
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {tab === 'checklist' && (
          <div className="space-y-6 animate-fadeIn">
            <div className="flex justify-between items-center">
               <h2 className="text-2xl font-bold text-slate-800">Checklist Operacional</h2>
               <button onClick={() => { setEditingItemId(null); setShowItemModal(true); }} className="bg-indigo-600 text-white px-4 py-2 rounded-xl text-sm font-bold hover:bg-indigo-700 transition-all shadow-md">
                 <i className="fas fa-plus mr-2"></i> Adicionar Pergunta
               </button>
            </div>
            <div className="grid grid-cols-1 gap-4">
              {items.map((item, idx) => (
                <div 
                  key={item.id} 
                  onClick={() => openEditModal(item)}
                  className="bg-white p-6 rounded-3xl border border-slate-200 flex flex-col md:flex-row items-start md:items-center justify-between shadow-sm hover:border-indigo-400 hover:shadow-lg transition-all cursor-pointer group space-y-4 md:space-y-0"
                >
                  <div className="flex items-center space-x-6">
                    <span className="text-slate-200 font-black text-3xl group-hover:text-indigo-100 transition-colors">{String(idx + 1).padStart(2, '0')}</span>
                    <div>
                      <span className="bg-indigo-50 text-indigo-600 px-3 py-1 rounded-full text-[9px] font-black uppercase mb-2 inline-block border border-indigo-100">{item.category}</span>
                      <p className="text-slate-700 font-bold text-lg leading-tight group-hover:text-indigo-900 transition-colors">{item.question}</p>
                      <div className="mt-3 flex flex-wrap gap-1.5">
                        {item.assignedUserIds.map(uid => {
                          const u = users.find(usr => usr.id === uid);
                          return u ? (
                            <span key={uid} className="text-[9px] font-bold bg-slate-100 text-slate-500 px-2 py-0.5 rounded-md border border-slate-200">{u.name.split(' ')[0]}</span>
                          ) : null;
                        })}
                      </div>
                    </div>
                  </div>
                  <button onClick={(e) => removeItem(e, item.id)} className="text-slate-300 hover:text-red-500 p-2 self-end md:self-center bg-slate-50 rounded-xl hover:bg-red-50 transition-all">
                    <i className="fas fa-trash-alt"></i>
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* User Add Modal */}
      {showUserModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-md rounded-[2.5rem] p-10 shadow-2xl animate-fadeIn">
            <h3 className="text-2xl font-black text-slate-800 mb-8 tracking-tighter">Novo Colaborador</h3>
            <form onSubmit={handleAddUser} className="space-y-5">
              <div>
                <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1.5">Nome Completo</label>
                <input required className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:ring-2 focus:ring-indigo-500 font-medium" 
                  value={newUser.name} onChange={e => setNewUser({...newUser, name: e.target.value})} />
              </div>
              <div>
                <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1.5">Cargo / Função</label>
                <input required className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:ring-2 focus:ring-indigo-500 font-medium" 
                  value={newUser.role} onChange={e => setNewUser({...newUser, role: e.target.value})} />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1.5">WhatsApp</label>
                  <input required className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:ring-2 focus:ring-indigo-500 font-medium" 
                    value={newUser.phone} placeholder="5511..." onChange={e => setNewUser({...newUser, phone: e.target.value})} />
                </div>
                <div>
                  <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1.5">E-mail</label>
                  <input required type="email" className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:ring-2 focus:ring-indigo-500 font-medium" 
                    value={newUser.email} onChange={e => setNewUser({...newUser, email: e.target.value})} />
                </div>
              </div>
              <div className="flex space-x-3 pt-6">
                <button type="button" onClick={() => setShowUserModal(false)} className="flex-1 py-4 text-slate-400 font-bold hover:bg-slate-50 rounded-2xl transition-all">Cancelar</button>
                <button type="submit" className="flex-1 py-4 bg-indigo-600 text-white font-black rounded-2xl shadow-xl shadow-indigo-100 hover:bg-indigo-700 transition-all">Salvar Perfil</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Item Add/Edit Modal */}
      {showItemModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-lg rounded-[2.5rem] p-10 shadow-2xl animate-fadeIn overflow-hidden flex flex-col max-h-[95vh]">
            <h3 className="text-2xl font-black text-slate-800 mb-8 tracking-tighter">{editingItemId ? 'Editar Pergunta' : 'Nova Pergunta'}</h3>
            <form onSubmit={handleSaveItem} className="space-y-6 flex-1 flex flex-col overflow-hidden">
              <div className="flex-none">
                <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1.5">Descrição da Verificação</label>
                <textarea required className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:ring-2 focus:ring-indigo-500 min-h-[100px] font-medium text-lg leading-tight" 
                  value={newItem.question} onChange={e => setNewItem({...newItem, question: e.target.value})} />
              </div>
              <div className="flex-none">
                <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1.5">Segmento / Categoria</label>
                <input required className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:ring-2 focus:ring-indigo-500 font-medium" 
                  value={newItem.category} placeholder="Ex: Segurança, Manutenção, Limpeza..."
                  onChange={e => setNewItem({...newItem, category: e.target.value})} />
              </div>
              <div className="flex-1 flex flex-col overflow-hidden">
                <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">Colaboradores Autorizados</label>
                <div className="bg-slate-50 border border-slate-200 rounded-2xl p-5 overflow-y-auto space-y-2 flex-1 scrollbar-hide">
                  {users.map(u => (
                    <label key={u.id} className={`flex items-center space-x-4 cursor-pointer p-4 rounded-2xl border transition-all ${newItem.assignedUserIds.includes(u.id) ? 'bg-indigo-600 border-indigo-600 shadow-lg shadow-indigo-100 text-white' : 'bg-white border-slate-100 hover:border-indigo-300 text-slate-700'}`}>
                      <input 
                        type="checkbox" 
                        className="hidden"
                        checked={newItem.assignedUserIds.includes(u.id)}
                        onChange={() => toggleUserAssignment(u.id)}
                      />
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs ${newItem.assignedUserIds.includes(u.id) ? 'bg-indigo-500' : 'bg-slate-100'}`}>
                        {u.name.charAt(0)}
                      </div>
                      <div className="flex-1">
                        <p className="font-black text-sm">{u.name}</p>
                        <p className={`text-[9px] font-bold uppercase tracking-widest ${newItem.assignedUserIds.includes(u.id) ? 'text-indigo-200' : 'text-slate-400'}`}>{u.role}</p>
                      </div>
                      {newItem.assignedUserIds.includes(u.id) && (
                        <i className="fas fa-check-circle text-white"></i>
                      )}
                    </label>
                  ))}
                  {users.length === 0 && <p className="text-xs text-red-500 font-bold p-4 text-center bg-red-50 rounded-2xl">Cadastre colaboradores antes de criar itens.</p>}
                </div>
              </div>
              <div className="flex space-x-4 pt-6 bg-white border-t mt-auto">
                <button type="button" onClick={closeItemModal} className="flex-1 py-4 text-slate-400 font-bold hover:bg-slate-50 rounded-2xl transition-all">Descartar</button>
                <button type="submit" className="flex-1 py-4 bg-indigo-600 text-white font-black rounded-2xl shadow-xl shadow-indigo-100 hover:bg-indigo-700 transition-all">
                  {editingItemId ? 'Atualizar Item' : 'Concluir Item'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      <style>{`
        .scrollbar-hide::-webkit-scrollbar { display: none; }
        .scrollbar-hide { -ms-overflow-style: none; scrollbar-width: none; }
        @keyframes slideDown { from { transform: translateY(-20px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }
        @keyframes fadeIn { from { opacity: 0; transform: scale(0.98); } to { opacity: 1; transform: scale(1); } }
        .animate-slideDown { animation: slideDown 0.5s cubic-bezier(0.16, 1, 0.3, 1) forwards; }
        .animate-fadeIn { animation: fadeIn 0.4s cubic-bezier(0.16, 1, 0.3, 1) forwards; }
      `}</style>
    </div>
  );
};

export default AdminDashboard;
