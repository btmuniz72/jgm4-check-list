
import React, { useState } from 'react';
import { User, ChecklistItem, ChecklistResponse } from '../types';

interface UserChecklistProps {
  user: User;
  items: ChecklistItem[];
  onSubmit: (response: ChecklistResponse) => void;
  onCancel: () => void;
}

const UserChecklist: React.FC<UserChecklistProps> = ({ user, items, onSubmit, onCancel }) => {
  const [answers, setAnswers] = useState<Record<string, boolean>>({});
  const [notes, setNotes] = useState('');

  const toggleAnswer = (id: string, val: boolean) => {
    setAnswers(prev => ({ ...prev, [id]: val }));
  };

  const handleFinish = () => {
    // Check if all answered
    if (Object.keys(answers).length < items.length) {
      alert('Por favor, responda a todos os itens do checklist antes de finalizar.');
      return;
    }

    const response: ChecklistResponse = {
      id: crypto.randomUUID(),
      userId: user.id,
      date: new Date().toISOString(),
      answers,
      notes,
      timestamp: Date.now()
    };
    onSubmit(response);
  };

  return (
    <div className="max-w-3xl mx-auto w-full p-4 sm:p-6 mb-20">
      {/* Header Info */}
      <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm mb-6 flex flex-col sm:flex-row justify-between items-start sm:items-center">
        <div>
          <span className="text-xs font-bold text-indigo-500 uppercase tracking-widest">Preenchimento Ativo</span>
          <h2 className="text-xl font-bold text-slate-800">{user.name}</h2>
          <p className="text-sm text-slate-500">{user.role}</p>
        </div>
        <button onClick={onCancel} className="mt-4 sm:mt-0 text-slate-400 hover:text-red-500 transition-colors">
          <i className="fas fa-times-circle mr-1"></i> Cancelar
        </button>
      </div>

      {/* Checklist Items */}
      <div className="space-y-4">
        {items.map((item, idx) => (
          <div key={item.id} className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm transition-all hover:border-indigo-100">
            <div className="flex justify-between items-start mb-4">
               <span className="px-2 py-0.5 bg-slate-100 text-slate-500 rounded text-[10px] font-bold uppercase">{item.category}</span>
               <span className="text-slate-300 text-xs font-bold">#{idx + 1}</span>
            </div>
            <p className="text-slate-800 font-medium mb-5">{item.question}</p>
            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={() => toggleAnswer(item.id, true)}
                className={`py-3 px-4 rounded-xl font-bold flex items-center justify-center transition-all ${
                  answers[item.id] === true 
                  ? 'bg-green-500 text-white shadow-lg shadow-green-100' 
                  : 'bg-slate-50 text-slate-400 border border-slate-200 hover:bg-green-50'
                }`}
              >
                <i className="fas fa-check-circle mr-2"></i> CONFORME
              </button>
              <button
                onClick={() => toggleAnswer(item.id, false)}
                className={`py-3 px-4 rounded-xl font-bold flex items-center justify-center transition-all ${
                  answers[item.id] === false 
                  ? 'bg-red-500 text-white shadow-lg shadow-red-100' 
                  : 'bg-slate-50 text-slate-400 border border-slate-200 hover:bg-red-50'
                }`}
              >
                <i className="fas fa-times-circle mr-2"></i> NÃO CONFORME
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Observation */}
      <div className="mt-6 bg-white p-6 rounded-3xl border border-slate-200 shadow-sm">
        <label className="block text-sm font-bold text-slate-700 mb-2">Observações Adicionais (opcional)</label>
        <textarea
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          className="w-full bg-slate-50 border border-slate-200 rounded-xl p-4 min-h-[100px] outline-none focus:ring-2 focus:ring-indigo-500 transition-all text-sm"
          placeholder="Descreva qualquer detalhe relevante sobre a jornada..."
        ></textarea>
      </div>

      {/* Floating Action Bar */}
      <div className="fixed bottom-0 left-0 right-0 p-4 bg-white border-t border-slate-200 flex justify-center z-40">
        <button
          onClick={handleFinish}
          className="w-full max-w-md bg-indigo-600 text-white font-bold py-4 rounded-2xl shadow-xl shadow-indigo-100 hover:bg-indigo-700 transition-all active:scale-95 flex items-center justify-center"
        >
          <i className="fas fa-paper-plane mr-2"></i> FINALIZAR E NOTIFICAR
        </button>
      </div>
    </div>
  );
};

export default UserChecklist;
